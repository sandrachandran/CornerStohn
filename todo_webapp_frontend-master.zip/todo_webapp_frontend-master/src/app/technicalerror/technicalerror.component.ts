import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technicalerror',
  templateUrl: './technicalerror.component.html',
  styleUrls: ['./technicalerror.component.css']
})
export class TechnicalerrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
